# Último Cartucho para Android

Este proyecto envuelve el juego en una app de Android (un WebView a pantalla completa, en horizontal). El juego está en `app/src/main/assets/index.html`.

Controles en el celu: stick izquierdo para moverte, stick derecho para apuntar (dispara solo mientras lo mantenés inclinado). Abajo hay botones para mejoras, cambiar de arma, recargar y pausa. El botón atrás pausa la partida o vuelve al menú.

## Sacar el APK gratis, sin instalar nada (GitHub Actions)

1. Creá un repositorio nuevo en GitHub (puede ser privado) y subí todo el contenido de esta carpeta, incluida la carpeta oculta `.github`.
2. Entrá a la pestaña **Actions**, elegí **Build APK** y tocá **Run workflow**.
3. Cuando termine (unos 3 a 5 minutos), abrí la ejecución y bajá el artefacto **ultimo-cartucho-apk**. Adentro está `app-debug.apk`.
4. Pasalo al celu e instalalo. Android te va a pedir permitir instalar apps de orígenes desconocidos.

## Con Android Studio

1. Abrí esta carpeta con Android Studio y esperá a que sincronice.
2. Menú **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Por línea de comandos

Con JDK 17 y el SDK de Android instalado: `./gradlew assembleDebug`.

## Notas

- El APK es de depuración: se instala sin problema, pero no sirve para subirlo a Google Play. Para Play hay que firmar un `release` con tu propia clave.
- La app pide permiso de internet solo para bajar las tipografías de Google Fonts. Sin conexión, el juego usa tipografías de reemplazo y funciona igual.
- Para actualizar el juego, reemplazá `app/src/main/assets/index.html` y volvé a compilar.
